import javax.swing.*;
import model.*;
import service.RecyclingLocator;
import java.util.List;

public class DialogUI {

    private RecyclingLocator locator = new RecyclingLocator();

    public static void main(String[] args) {
        DialogUI ui = new DialogUI();
        ui.menu();
    }

    private void menu() {
        String[] options = {
                "Load Centres from File",
                "View All Centres",
                "Search by Material",
                "Find Nearest Centre",
                "Find Centres in Radius",
                "Exit"
        };

        while (true) {
            int choice = JOptionPane.showOptionDialog(
                    null,
                    "Recycling Centre Locator",
                    "Main Menu",
                    JOptionPane.DEFAULT_OPTION,
                    JOptionPane.INFORMATION_MESSAGE,
                    null,
                    options,
                    options[0]
            );

            if (choice == 5 || choice == -1) {
                JOptionPane.showMessageDialog(null, "Goodbye!");
                System.exit(0);
            }

            switch (choice) {
                case 0 -> loadCentres();
                case 1 -> viewAllCentres();
                case 2 -> searchByMaterial();
                case 3 -> findNearestCentre();
                case 4 -> findCentresInRadius();
            }
        }
    }

    private void loadCentres() {
        String file = JOptionPane.showInputDialog(null,
                "Enter file name (e.g. centres.txt or src/centres.txt):");

        if (file == null || file.isEmpty()) return;

        locator.initialize(file);
        JOptionPane.showMessageDialog(null,
                "Loaded " + locator.getCentreCount() + " centres successfully.");
    }

    private void viewAllCentres() {
        List<RecyclingCentre> centres = locator.getServiceLogic().getCentres();

        if (centres.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No centres loaded.");
            return;
        }

        StringBuilder sb = new StringBuilder();
        for (RecyclingCentre c : centres) {
            sb.append(formatCentre(c)).append("\n---------------------\n");
        }

        showLongText("All Centres", sb.toString());
    }

    private void searchByMaterial() {
        String input = JOptionPane.showInputDialog(null,
                "Enter material (PLASTIC, GLASS, PAPER, METAL, ELECTRONIC, ORGANIC, TEXTILE):");

        if (input == null) return;

        try {
            Material material = Material.valueOf(input.trim().toUpperCase());
            List<RecyclingCentre> results = locator.findCentresByMaterial(material);

            if (results.isEmpty()) {
                JOptionPane.showMessageDialog(null, "No centres accept " + material);
                return;
            }

            StringBuilder sb = new StringBuilder("Centres accepting " + material + ":\n\n");
            for (RecyclingCentre c : results) {
                sb.append(formatCentre(c)).append("\n---------------------\n");
            }

            showLongText("Results", sb.toString());

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,
                    "Invalid material entered.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void findNearestCentre() {
        Integer x = getInt("Enter your X coordinate:");
        if (x == null) return;
        Integer y = getInt("Enter your Y coordinate:");
        if (y == null) return;

        Location user = new Location("User", x, y);

        RecyclingCentre nearest = locator.findNearestCentre(user);
        if (nearest == null) {
            JOptionPane.showMessageDialog(null, "No centres loaded.");
            return;
        }

        double dist = nearest.getLocation().computeDistance(user);

        String message = formatCentre(nearest)
                + "\nDistance: " + String.format("%.2f", dist);

        showLongText("Nearest Centre", message);
    }

    private void findCentresInRadius() {
        Integer x = getInt("Enter your X coordinate:");
        if (x == null) return;
        Integer y = getInt("Enter your Y coordinate:");
        if (y == null) return;

        Double radius = getDouble("Enter radius:");
        if (radius == null) return;

        Location user = new Location("User", x, y);

        List<RecyclingCentre> results = locator.findCentresInRadius(user, radius);

        if (results.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No centres found.");
            return;
        }

        StringBuilder sb = new StringBuilder("Centres within " + radius + " units:\n\n");

        for (RecyclingCentre c : results) {
            double dist = c.getLocation().computeDistance(user);
            sb.append(formatCentre(c))
              .append("\nDistance: ").append(String.format("%.2f", dist))
              .append("\n---------------------\n");
        }

        showLongText("Nearby Centres", sb.toString());
    }

    // Utility Methods

    private Integer getInt(String message) {
        while (true) {
            String x = JOptionPane.showInputDialog(null, message);
            if (x == null) return null;
            try {
                return Integer.parseInt(x.trim());
            } catch (Exception ignored) {
                JOptionPane.showMessageDialog(null, "Enter a valid integer.");
            }
        }
    }

    private Double getDouble(String message) {
        while (true) {
            String x = JOptionPane.showInputDialog(null, message);
            if (x == null) return null;
            try {
                return Double.parseDouble(x.trim());
            } catch (Exception ignored) {
                JOptionPane.showMessageDialog(null, "Enter a valid number.");
            }
        }
    }

    private void showLongText(String title, String text) {
        JTextArea area = new JTextArea(text, 20, 50);
        area.setWrapStyleWord(true);
        area.setLineWrap(true);
        area.setEditable(false);

        JScrollPane scroll = new JScrollPane(area);

        JOptionPane.showMessageDialog(null, scroll, title, JOptionPane.INFORMATION_MESSAGE);
    }

    private String formatCentre(RecyclingCentre c) {
        return "Name: " + c.getName()
                + "\nType: " + (c instanceof EcoRecyclingCentre ? "Eco Centre" : "Regular Centre")
                + "\nPlace: " + c.getLocation().getPlaceName()
                + "\nCoordinates: (" + c.getLocation().getX() + ", " + c.getLocation().getY() + ")"
                + "\nAccepts: " + c.getMaterials();
    }
}
